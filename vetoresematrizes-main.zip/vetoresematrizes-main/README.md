# VETORES E MATRIZES - PORTUGOL STUDIO (2022)

Soluções dos exercícios do dia 28/03/2022;
Módulo: Lógica da Programação;
Assunto: Vetores e Matrizes;
Professor: Luis Guerreiro;
Programa utilizado: Portugol Studio;
Bootcamp: Generation Brasil 2022.1.

Exercícios com Vetores[ ] e Matrizes [ ][ ]

1. Faça um programa que crie um vetor por leitura com 5 valores de pontuação de uma atividade e o escreva em seguida. Encontre após a maior pontuação e a apresente.

2. Um dado é lançado 10 vezes e o valor correspondente é anotado. Faça um programa que gere um vetor com os lançamentos, escreva esse vetor. A seguir determine e imprima a média aritmética dos lançamentos, contabilize e apresente também quantas foram as ocorrências da maior pontuação.

3. Escreve um programa que lê duas matrizes N1 (4,6) e N2(4,6) e cria:

a) Uma matriz M1 cujos elementos serão as somas dos elementos de mesma posição
das matrizes N1 e N2;
b) Uma matriz M2 cujos elementos serão as diferenças dos elementos de mesma
posição das matrizes N1 e N2.

4. Crie um programa que receba valores do usuário para preencher uma matriz 3X3, e em seguida, exiba a soma dos valores dela e a soma dos valores da primeira diagonal, ou seja, diagonal principal.

As soluções apresentadas foram desenvolvidas por #@BabbiOliveira# e estão disponíveis neste repositório.
